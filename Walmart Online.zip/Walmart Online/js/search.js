function Search() {
	const proxyurl = "https://cors-anywhere.herokuapp.com/";
	var query = document.getElementById("search").value;
	sessionStorage.setItem('query', query);
	window.location.href="product.html";
}

function Single(id){
	sessionStorage.setItem('id', id);
	window.location.href="single.html";
}

function singleLoad(){
	var id = sessionStorage.getItem('id');
	var data = '';
	var query = sessionStorage.getItem('query');
	const proxyurl = "https://cors-anywhere.herokuapp.com/";
	const url = proxyurl + "http://api.walmartlabs.com/v1/items/"+id+"?format=json&apiKey=waszcb7captgb9ncmt9tt76p";
	fetch(url)
	.then(response => response.text())
	.then(contents => {
		obj = JSON.parse(contents);
		data += "<div class=\"col-md-5 single-right-left \"><img src=\""+obj.mediumImage+"\" data-imagezoom=\"true\" class=\"img-responsive\" alt=\"\"></div>"+
		"<div class=\"col-md-7 single-right-left simpleCart_shelfItem\">"+
		"<h3>"+obj.name+"</h3><p><span class=\"item_price\">$"+obj.salePrice+"</span>"+
		"<br/><label>Free delivery</label></p>"+
		"<div class=\"product-single-w3l\"><p>"+obj.shortDescription +  "<br/><br/>" + obj.longDescription+"</p></div>"+
		"</div><div class=\"clearfix\"></div></div>";	 
		console.log(data);
		document.getElementById("singleContent").innerHTML = data;
	})
	.catch(() => console.log("Can’t access " + url + " response. Potentially blocked by browser."))	
}

function SingleOnLoad(){
	console.log("HEY");
	var id = sessionStorage.getItem('id');
	var data = '';
	var query = sessionStorage.getItem('query');
	const proxyurl = "https://cors-anywhere.herokuapp.com/";
	const url = proxyurl + "http://api.walmartlabs.com/v1/items/"+id+"?format=json&apiKey=waszcb7captgb9ncmt9tt76p";
	fetch(url)
	.then(response => response.text())
	.then(contents => {
		obj = JSON.parse(contents);
		items = obj.numItems;
		console.log(obj);
		for (var i = 0; i < items; i++) { 
			data += "<div class=\"col-md-5 single-right-left \"><div class=\"grid images_3_of_2\"><div class=\"flexslider\"><ul class=\"slides\">"+
			"<li data-thumb=\""+obj.thumbnailImage+"\"><div class=\"thumb-image\"><img src=\""+obj.mediumImage+"\" data-imagezoom=\"true\" class=\"img-responsive\" alt=\"\"> </div>"+
			"</li></ul><div class=\"clearfix\"></div></div></div></div>"+
			"<div class=\"col-md-7 single-right-left simpleCart_shelfItem\">"+
			"<h3>"+obj.name+"</h3><p><span class=\"item_price\">$"+obj.salePrice+"</span>"+
			"<label>Free delivery</label></p>"+
			"<div class=\"product-single-w3l\"><p>"+obj.longDescription+"</p></div>"+
			"</div><div class=\"clearfix\"> </div></div>";
			document.getElementById("singleContent").innerHTML = data;				    
		}
	})
	.catch(() => console.log("Can’t access " + url + " response. Potentially blocked by browser."))	
	console.log(data);
	document.getElementById("searchContent").innerHTML = data;
}

function Parse(){
	var data = '';
	var query = sessionStorage.getItem('query');
	const proxyurl = "https://cors-anywhere.herokuapp.com/";
	const url = proxyurl + "http://api.walmartlabs.com/v1/search?apiKey=waszcb7captgb9ncmt9tt76p&query=" + query;
	fetch(url)
	.then(response => response.text())
	.then(contents => {
		obj = JSON.parse(contents);
		items = obj.numItems;
		console.log(obj);
		for (var i = 0; i < items; i++) { 
			data += "<div class=\"col-xs-12 product-men\">"+
			"<div class=\"men-pro-item simpleCart_shelfItem\">"+
			"<div class=\"men-thumb-item\">"+
			"<img src=\" " + obj.items[i].thumbnailImage + " \" alt=\"\">"+
			"<div class=\"men-cart-pro\">"+
			"<div class=\"inner-men-cart-pro\">"+
			"<a href=\"single.html\" class=\"link-product-add-cart\">Quick View</a>"+
			"</div></div></div><div class=\"item-info-product \"><h4>"+
			"<div class=\"info-product-name\">"+
			"<span class=\"item_name\">$ " + obj.items[i].name + " </span></div>"+
			"<button type=\"submit\" id=\"" + obj.items[i].itemId + "\" onclick=\"Single(this.id)\">Info</button></h4>"+
			"<div class=\"info-product-price\">"+
			"<span class=\"item_price\">$ " + obj.items[i].salePrice + " </span>"+
			"</div><div class=\"snipcart-details top_brand_home_details item_add single-item hvr-outline-out\">"+
			"<form action=\"#\" method=\"post\">"+
			"<fieldset><input type=\"hidden\" name=\"cmd\" value=\"_cart\" />"+
			"<input type=\"hidden\" name=\"add\" value=\"1\" />"+
			"<input type=\"hidden\" name=\"business\" value=\" \" />"+
			"<input type=\"hidden\" name=\"item_name\" value=\" " + obj.items[i].name + " \" />"+
			"<input type=\"hidden\" name=\"amount\" value=\" " + obj.items[i].salePrice + " \" />"+
			"<input type=\"hidden\" name=\"discount_amount\" value=\"1.00\" />"+
			"<input type=\"hidden\" name=\"currency_code\" value=\"USD\" />"+
			"<input type=\"hidden\" name=\"return\" value=\" \" />"+
			"<input type=\"hidden\" name=\"cancel_return\" value=\" \" />"+
			"</fieldset></form></div></div></div></div>";
			document.getElementById("searchContent").innerHTML = data;				    
		}
	})
	.catch(() => console.log("Can’t access " + url + " response. Potentially blocked by browser."))	
	console.log(data);
	document.getElementById("searchContent").innerHTML = data;
}

function HomeOnLoad(){
	var data = '';
	var query = sessionStorage.getItem('query');
	const proxyurl = "https://cors-anywhere.herokuapp.com/";
	const url = proxyurl + "http://api.walmartlabs.com/v1/trends?format=json&apiKey=waszcb7captgb9ncmt9tt76p";
	fetch(url)
	.then(response => response.text())
	.then(contents => {
		obj = JSON.parse(contents);
		items = obj.numItems;
		console.log(obj);
		for (var i = 0; i < 10; i++) { 
			data += "<div class=\"col-xs-12 product-men\">"+
			"<div class=\"men-pro-item \">"+
			"<div class=\"men-thumb-item\">"+
			"<img src=\" " + obj.items[i].thumbnailImage + " \" alt=\"\">"+
			"<div class=\"men-cart-pro\">"+
			"<div class=\"inner-men-cart-pro\">"+
			"<a href=\"single.html\" class=\"link-product-add-cart\">Quick View</a>"+
			"</div></div></div><div class=\"item-info-product \"><h4>"+
			"<div class=\"info-product-name\">"+
			"<span class=\"item_name\">$ " + obj.items[i].name + " </span></div>"+
			"<button type=\"submit\" id=\"" + obj.items[i].itemId + "\" onclick=\"Single(this.id)\">Info</button></h4>"+
			"<div class=\"info-product-price\">"+
			"<span class=\"item_price\">$ " + obj.items[i].salePrice + " </span>"+
			"</div><div class=\"snipcart-details top_brand_home_details item_add single-item hvr-outline-out\">"+
			"<form action=\"#\" method=\"post\">"+
			"<fieldset><input type=\"hidden\" name=\"cmd\" value=\"_cart\" />"+
			"<input type=\"hidden\" name=\"add\" value=\"1\" />"+
			"<input type=\"hidden\" name=\"business\" value=\" \" />"+
			"<input type=\"hidden\" name=\"item_name\" value=\" " + obj.items[i].name + " \" />"+
			"<input type=\"hidden\" name=\"amount\" value=\" " + obj.items[i].salePrice + " \" />"+
			"<input type=\"hidden\" name=\"discount_amount\" value=\"1.00\" />"+
			"<input type=\"hidden\" name=\"currency_code\" value=\"USD\" />"+
			"<input type=\"hidden\" name=\"return\" value=\" \" />"+
			"<input type=\"hidden\" name=\"cancel_return\" value=\" \" />"+
			"</fieldset></form></div></div></div></div>";				    
		}
		document.getElementById("homeContent").innerHTML = data;
	})
	.catch(() => console.log("Can’t access " + url + " response. Potentially blocked by browser."))	
	console.log(data);
	document.getElementById("homeContent").innerHTML = data;
}